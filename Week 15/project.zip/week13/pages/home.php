<?php
$title = 'Home Page';
$content = loadTemplate('../templates/home_template.php', []);