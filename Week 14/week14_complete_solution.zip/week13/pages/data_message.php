<?php
$message = new DatabaseTable('message'); // create person object
$stmt = $message->findAll();